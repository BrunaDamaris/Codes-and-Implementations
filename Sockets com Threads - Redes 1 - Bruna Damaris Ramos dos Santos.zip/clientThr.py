import socket

address = ("localhost", 9503)

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect(address)

while True:
    text = input("Informe texto ou digite 'sair' para desconectar: ")
    text = str.encode(text, 'utf-8')
    client_socket.send(text)
    if (text.decode() == "sair"):
        print("Desconectado")
        client_socket.close()
        break
