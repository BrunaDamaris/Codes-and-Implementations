import socket
from _thread import *
import threading 
import _thread
import sys

def Threads(server_input,address):
    while True:
        response = server_input.recv(1024)
        response = response.decode()
        response = response.rstrip()
        if (response != "sair"):
            print ("Cliente: ", address," - Mensagem do cliente: ", response)
        else:
            print("Conexao encerrada com: ", address)
            server_input.close()
            sys.exit()
            break
    return


if __name__ == "__main__":
    
    address = ("localhost", 9503)

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    server_socket.bind(address)
    server_socket.listen(1024)
    
    while True:
        server_input, address = server_socket.accept()
        print ("Nova conexao recebida de ", address)
        thr = threading.Thread(target=Threads, args=(server_input,address))
        thr.start()